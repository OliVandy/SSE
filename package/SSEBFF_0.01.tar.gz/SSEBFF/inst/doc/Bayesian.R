## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## -----------------------------------------------------------------------------
library(SSEBFF)

## -----------------------------------------------------------------------------
BESS_unified(theta0 = 0.1, c = 0.95, e = 0.2, type = "one.sample",
             outcome = 1, a = 1, b = 1, q = 0.5)

## -----------------------------------------------------------------------------
Post_Prob_Bayes(type = "one.sample", n = 30, theta0 = 178, outcome = 2, e = 175, sig = 4, a = 170, b = 10)

## -----------------------------------------------------------------------------
BESS_SSR_Design(type = "one.sample", theta_H = 5,
                theta_s = 4, c = 0.95, c_s = 0.1, n0 = 60,
                outcome = 3)

## -----------------------------------------------------------------------------
Count_Sample_Size(type = "two.sample",
                  threshold = 1, # We assume A is 1 shot/game better than B
                  crit = 0.9, effect_size = 2, a_t = 0.5, b_t = 0.5, a_c = 0.5, b_c = 0.5)

## -----------------------------------------------------------------------------
Count_Post_Prob(type = "one.sample", total_count = 45, sample_size = 20,
                threshold = 2.5, a_t = 0.5, b_t = 0.5)

## -----------------------------------------------------------------------------
Two_Arm_Standard_SSE_Design(
  n_f     = 100,
  theta_H = 0.65,
  theta_L = 0.50,
  theta_s = 0.10,
  alpha   = 0.025,
  interim = TRUE,
  n_0     = 50)

## -----------------------------------------------------------------------------
Two_Arm_Combined_Sample_Size(
  type = "continuous",
  threshold = 0.2,
  crit = 0.9,
  effect_size = 0.4,
  prior_mean = 0,
  prior_sd = 1,
  sigma = 1)

## -----------------------------------------------------------------------------
Two_Arm_Combined_Post_Prob(
  type = "continuous",
  sample_size = 50,
  threshold = 0,
  effect_size = 0.3,
  prior_mean = 0,
  prior_sd = 1,
  sigma = 1,
  quant = 0.5
)

