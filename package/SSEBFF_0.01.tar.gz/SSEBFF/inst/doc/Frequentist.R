## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## -----------------------------------------------------------------------------
library(SSEBFF)

## -----------------------------------------------------------------------------
Freq_Binary_theoretical(alpha = 0.05, beta = 0.2, theta1 = 0.9, theta0 = 0.2)
# theta1 is the expected proportion of right-handed individuals, and theta0 is the expected proportion of left-handed individuals.

## -----------------------------------------------------------------------------
t_test_sim_sample_size(alpha = 0.05, beta = 0.2, mu1 = 174, mu0 = 163,
                       sigma1 = 6.5, sigma0 = 6,
                       type = "two.sample",
                       nmin = 10, nmax = 5000, sims = 10000)
# mu1 is the expected mean height for male, and mu0 is the expected mean height for female. Sigma1 is the standard deviation of collected male height data, and sigma0 is the standard deviation of collected female height data.

## -----------------------------------------------------------------------------
Freq_Count_Combined(
  alpha = 0.05,
  beta = 0.1,
  mu1 = 12,    # Player A's shot rate
  mu0 = 8,     # Player B's shot rate
  sig1 = 2,    # Standard deviation of Player A's shot rate
  sig0 = 1.5,  # Standard deviation of Player B's shot rate
  type = "two.sample",
  nmin = 5,
  nmax = 300,
  sims = 100
)

